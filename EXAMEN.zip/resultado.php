<!DOCTYPE html>
<html>
<head>
	<title>Resultados</title>
</head>
<body>
	<center><h1>Resultados</h1></center>
	<?php
	echo "El resultado es:";
	echo $_POST['Tabla']*$_POST['Multiplicador'];
	
	

	 ?>

</body>
</html>