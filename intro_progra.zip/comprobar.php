<!DOCTYPE html>
<html>
<head>
	<title>Comprobación</title>
</head>
<body>
	<h1>Resultados</h1>
	<<?php 
	if ($_POST['Calificación1']>=70) {
		echo "Alumno1 <br>";
		echo $_POST['Nombre1']; echo " aprobó la materia con:"; echo $_POST['Calificación1'];
	}else{echo "Alumno1";
		echo $_POST['Nombre1']; echo "reprobo la materia con:"; echo $_POST['Calificación1'];}
		echo "<br>";
		echo "<br>";

		if ($_POST['Calificación2']>=70) {
		echo "Alumno2 <br>";
		echo $_POST['Nombre2']; echo " aprobó la materia con:"; echo $_POST['Calificación2'];
	}else{echo "Alumno2";
		echo $_POST['Nombre2']; echo "reprobo la materia con:"; echo $_POST['Calificación2'];}
		echo "<br>";
		echo "<br>";

		if ($_POST['Calificación3']>=70) {
		echo "Alumno3 <br>";
		echo $_POST['Nombre3']; echo " aprobó la materia con:"; echo $_POST['Calificación3'];
	}else{echo "Alumno3";
		echo $_POST['Nombre3']; echo "reprobo la materia con:"; echo $_POST['Calificación3'];}
		echo "<br>";
		echo "<br>";

		if ($_POST['Calificación4']>=70) {
		echo "Alumno4 <br>";
		echo $_POST['Nombre4']; echo " aprobó la materia con:"; echo $_POST['Calificación4'];
	}else{echo "Alumno4";
		echo $_POST['Nombre4']; echo "reprobo la materia con:"; echo $_POST['Calificación4'];}
		echo "<br>";
		echo "<br>";

		if ($_POST['Calificación5']>=70) {
		echo "Alumno5 <br>";
		echo $_POST['Nombre5']; echo " aprobó la materia con:"; echo $_POST['Calificación5'];
	}else{echo "Alumno5";
		echo $_POST['Nombre5']; echo "reprobo la materia con:"; echo $_POST['Calificación5'];}
		
	
	 ?>
	

</body>
</html>