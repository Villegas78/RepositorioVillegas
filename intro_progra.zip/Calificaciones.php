<!--Si la calificacion es mayor a 7, imprimir aprobado, caso contrario reprobado, hacer para 5 personas -->

	<!DOCTYPE html>
	<html>
	<head>
		<title>Calificaciones</title>
	</head>
	<form action="comprobar.php" method="post"/>

	<body bgcolor="green">
		<center><h1>Muestreo de Calificaciones</h1></center>
		<input type="text" size ="25"name="Nombre1">
		<input type="number" name="Calificación1"><br>
		<br>
		<br>
		<input type="text" size ="25"name="Nombre2">
		<input type="number" name="Calificación2"><br>
		<br>
		<br>
		<input type="text" size ="25"name="Nombre3">
		<input type="number" name="Calificación3"><br>
		<br>
		<br>
		<input type="text" size ="25"name="Nombre4">
		<input type="number" name="Calificación4"><br>
		<br>
		<br>
		<input type="text" size ="25"name="Nombre5">
		<input type="number" name="Calificación5"><br>
		<br>
		<br>

		<input type="submit" name="Comprobar">
		<input type="reset" value="Reiniciar">
		</form>
	</body>
	</html>